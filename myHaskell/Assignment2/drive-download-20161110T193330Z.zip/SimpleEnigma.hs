module SimpleEnigma where

import Ciphers16
import AssignmentHelp

-----------------------------------------
--task1
-----------------------------------------

type Rotor = Cipher
type Reflector = [(Char, Char)]
type Steckerboard = [(Char, Char)]
data Enigma = SimpleEnigma [Rotor] Reflector
              | SteckeredEnigma [Rotor] Reflector Steckerboard

sampleReflector = [('A','Y'),('B','R'),('C','U'),('D','H'),('E','Q'),('F','S'),('G','L'),('I','P'),('J','X'),('K','N'),('M','O'),('T','Z'),('V','W')]
sampleSteckerboard = [('Q','W'),('E','R'),('T','Y'),('U','I'),('O','P'),('A','S'),('D','F'),('G','H'),('J','K'),('L','Z'),('X','C')]

sampleEnigma = SimpleEnigma [rotor1,rotor2,rotor3,rotor4,rotor5] sampleReflector
sampleStEnigma = SteckeredEnigma [rotor1,rotor2,rotor3,rotor4,rotor5] sampleReflector sampleSteckerboard

-----------------------------------------
--task2
-----------------------------------------

enigmaEncode :: Enigma -> [Int] -> [Int] -> Char -> Char
enigmaEncode (SimpleEnigma rts rf) setRotors offsets letter =
 let
  setting = zip (map (\n -> rts!!n) setRotors) offsets
  reflection = reflect rf (foldr (\ (r,o) l -> encode r o l) letter setting)
 in
  foldl (\ l (r,o) -> reverseEncode r o l) reflection setting

enigmaEncode (SteckeredEnigma rts rf sb) setRts ofs l =
 reflect sb (enigmaEncode (SimpleEnigma rts rf) setRts ofs (reflect sb l))

reflect :: Reflector -> Char -> Char
reflect [] l = l
reflect ((a, b): t) l
 |a==l = b
 |b==l = a
 |otherwise = reflect t l


-----------------------------------------
--task3
-----------------------------------------

enigmaEncodeMessage :: Enigma -> [Int] -> [Int] -> String -> String
enigmaEncodeMessage _ _ _ [] = []

enigmaEncodeMessage (SimpleEnigma rts rf) setRotors offsets (mh:mt) =
 (enigmaEncode (SimpleEnigma rts rf) setRotors newOffsets mh): (enigmaEncodeMessage (SimpleEnigma rts rf) setRotors newOffsets mt)
 where newOffsets = advance offsets

enigmaEncodeMessage (SteckeredEnigma rts rf sb) setRts ofs (mh:mt) =
 (enigmaEncode (SteckeredEnigma rts rf sb) setRts newofs mh): (enigmaEncodeMessage (SteckeredEnigma rts rf sb) setRts newofs mt)
 where newofs = advance ofs

advance :: [Int] -> [Int]
advance offsets = map (\n -> mod n 26) (keydown offsets)

keydown :: [Int] -> [Int]
keydown [a] = [a+1]
keydown (h:t) = (h + quot (head kt) 26): kt
 where kt = keydown t

-----------------------------------------
--task5
-----------------------------------------





-----------------------------------------
--task7
-----------------------------------------


type Crib = [(Char, Char)]
type Menu = [Int]



-----------------------------------------
--task8
-----------------------------------------

longestMenu :: Crib -> Menu
longestMenu cr =

search :: Crib -> Char -> [String]
search cr l
 let
  successor = filter (\ (a, _) -> a==l) cr
  newcr = cr
 |map (\ c -> l : fst c) map search 

choose :: Crib -> String -> Char
choose cr (h:t) = (search cr h):choose cr t



