/**
*	PilesSearch.java*
*	game search for piles problems (Grundy's game)
*   subclass of GameSearch
*/



import java.util.*;

public class PilesSearch extends GameSearch {

  //constructor

  /**
   * create a new search
   */

    public  PilesSearch () {}


}










